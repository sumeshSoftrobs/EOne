package com.example.eone.mainLayouts.home;

import android.arch.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}